//functional interface
interface InterestRate {
	float forPeriod(int years);
}

